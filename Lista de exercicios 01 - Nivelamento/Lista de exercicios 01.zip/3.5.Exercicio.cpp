/* Programa: 
Autor: Matheus de Assis Carvalho
Data de criacao: 26/08/2020
Data de Modifocacao: 26/08/2020
*/
/*
3.5) Solicitar um n�mero entre 1 e 4. Se a pessoas digitar um n�mero diferente, mostrar a
mensagem "entrada inv�lida" e solicitar o n�mero novamente. Se digitar correto mostrar o n�mero digitado.
*/
#include <stdio.h>
#include <stdlib.h> 
#include <locale.h>
#include <conio.h>
#include <string.h>
main()
{
	int numero;
	
	printf("Digite um numero entre 1 e 4: ");
	scanf("%d", &numero);
	
	
	while(numero < 1 || numero > 4){
		if (numero > 1 || numero < 4){
			printf("Numero invalido!\n");
			printf("Digite um numero entre 1 e 4: ");
			scanf("%d", &numero);
		} else {
			break;
		}
	}
	
	printf("\nNumero digitado: %d\n\n", numero);
	printf("Saindo do programa");
}
